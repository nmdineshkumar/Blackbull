'use strict';
$(document).ready(function() {

    // [ session-scroll ] start
    var px = new PerfectScrollbar('.session-scroll', {
        wheelSpeed: .5,
        swipeEasing: 0,
        wheelPropagation: 1,
        minScrollbarLength: 40,
    });
    // [ session-scroll ] end

});
